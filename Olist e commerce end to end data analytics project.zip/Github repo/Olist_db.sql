Select*
FROM olist_order_reviews_dataset;